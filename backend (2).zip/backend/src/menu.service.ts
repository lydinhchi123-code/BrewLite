import { Injectable, OnModuleDestroy, OnModuleInit, ServiceUnavailableException } from '@nestjs/common';
import { Pool } from 'pg';

@Injectable()
export class MenuService implements OnModuleInit, OnModuleDestroy {
  private readonly pool = new Pool({
    connectionString: process.env.DATABASE_URL,
    // PostgreSQL local development typically does not require SSL.
    ssl: process.env.PGSSL === 'true' ? { rejectUnauthorized: false } : undefined,
  });

  async onModuleInit() {
    if (!process.env.DATABASE_URL) {
      throw new Error('Thiếu DATABASE_URL. Hãy khai báo chuỗi kết nối PostgreSQL trong file .env.');
    }
    try {
      await this.pool.query('SELECT 1');
    } catch (error) {
      throw new Error(
        `Không thể kết nối PostgreSQL. Hãy kiểm tra DATABASE_URL và trạng thái PostgreSQL. Chi tiết: ${
          error instanceof Error ? error.message : String(error)
        }`,
      );
    }
  }

  async onModuleDestroy() {
    await this.pool.end();
  }

  async getCategories() {
    try {
      const result = await this.pool.query(`
        SELECT id, name, slug, description, image_url, display_order
        FROM menu_categories
        WHERE is_active = TRUE
        ORDER BY display_order ASC, name ASC
      `);
      return result.rows;
    } catch (error) {
      this.handleDatabaseError(error);
    }
  }

  async getProducts() {
    try {
      const result = await this.pool.query(`
        SELECT
          p.id,
          p.name,
          p.slug,
          p.description,
          p.image_url,
          p.base_price,
          p.is_featured,
          p.is_available,
          p.display_order,
          c.id AS category_id,
          c.name AS category_name,
          c.slug AS category_slug
        FROM menu_products p
        LEFT JOIN menu_categories c ON c.id = p.category_id
        WHERE p.is_available = TRUE
          AND (c.id IS NULL OR c.is_active = TRUE)
        ORDER BY p.display_order ASC, p.name ASC
      `);

      // Keep both nested and flat category fields so the frontend can consume
      // this response without coupling to one naming convention.
      return result.rows.map((row) => ({
        ...row,
        basePrice: Number(row.base_price),
        imageUrl: row.image_url,
        isFeatured: row.is_featured,
        categoryName: row.category_name,
        categorySlug: row.category_slug,
        category: row.category_id
          ? { id: row.category_id, name: row.category_name, slug: row.category_slug }
          : null,
      }));
    } catch (error) {
      this.handleDatabaseError(error);
    }
  }

  private handleDatabaseError(error: unknown): never {
    const message = error instanceof Error ? error.message : String(error);
    throw new ServiceUnavailableException(
      `Không đọc được dữ liệu menu. Hãy kiểm tra bảng menu_categories/menu_products đã được tạo và đã có dữ liệu. Chi tiết: ${message}`,
    );
  }
}
